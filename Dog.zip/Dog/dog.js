const hungerElement = document.getElementById("hunger");
const happinessElement = document.getElementById("happiness");
const energyElement = document.getElementById("energy");
const dogImage = document.getElementById("dog-image");

let hunger = 5;
let happiness = 5;
let energy = 5;

const barkSound = new Audio("sounds/bark.mp3");
const eatingSound = new Audio("sounds/eating.mp3");
const playSound = new Audio("sounds/play.mp3");
const tiredSound = new Audio("sounds/tired.mp3");

function updateStats() {
    hungerElement.textContent = `Hunger: ${hunger}`;
    happinessElement.textContent = `Happiness: ${happiness}`;
    energyElement.textContent = `Energy: ${energy}`;

    if (hunger <= 2) {
        dogImage.src = "Icons/hungry-dog.jpg";
        dogImage.style.filter = "grayscale(100%)";
        tiredSound.play();
    } else if (happiness <= 2) {
        dogImage.src = "Icons/sad-dog.jpg";
        dogImage.style.filter = "grayscale(50%)";
        tiredSound.play();
    } else if (energy <= 2) {
        dogImage.src = "Icons/tired-dog.jpg";
        dogImage.style.filter = "grayscale(50%)";
        tiredSound.play();
    } else {
        dogImage.src = "Icons/happy-dog.png";
        dogImage.style.filter = "none";
        barkSound.play();
    }
}

document.getElementById("feed-btn").addEventListener("click", () => {
    if (hunger < 10) {
        hunger++;
        happiness++;
        eatingSound.play();  
        updateStats();
    }
});

document.getElementById("play-btn").addEventListener("click", () => {
    if (happiness < 10 && energy > 0) {
        happiness++;
        energy--;
        playSound.play();  // Play fun sound
        updateStats();
    }
});

document.getElementById("walk-btn").addEventListener("click", () => {
    if (energy > 0 && hunger > 0) {
        happiness++;
        hunger--;
        energy--;
        playSound.play();  // Play sound for walking
        updateStats();
    }
});

document.getElementById("rest-btn").addEventListener("click", () => {
    if (energy < 10) {
        energy++;
        barkSound.play();  // Bark after resting
        updateStats();
    }
});

// Automatic stats decrease every 5 seconds
setInterval(() => {
    if (hunger > 0) hunger--;
    if (happiness > 0) happiness--;
    if (energy > 0) energy--;
    updateStats();
}, 5000);
