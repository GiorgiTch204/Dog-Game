const hungerElement = document.getElementById("hunger");
const happinessElement = document.getElementById("happiness");
const energyElement = document.getElementById("energy");
const dogImage = document.getElementById("dog-image");

let hunger = 5;
let happiness = 5;
let energy = 5;

function updateStats() {
    hungerElement.textContent = `Hunger: ${hunger}`;
    happinessElement.textContent = `Happiness: ${happiness}`;
    energyElement.textContent = `Energy: ${energy}`;

    if (hunger <= 2) {
        dogImage.src = "Icons/hungry";
    } else if (happiness <= 2) {
        dogImage.src = "";
    } else if (energy <= 2) {
        dogImage.src = "Icons/tired-dog";
    } else {
        dogImage.src = "Icons/happy-dog-with-big-tongue-out";
    }
}

document.getElementById("feed-btn").addEventListener("click", () => {
    if (hunger < 10) {
        hunger++;
        happiness++;
        updateStats();
    }
});

document.getElementById("play-btn").addEventListener("click", () => {
    if (happiness < 10 && energy > 0) {
        happiness++;
        energy--;
        updateStats();
    }
});

document.getElementById("walk-btn").addEventListener("click", () => {
    if (energy > 0 && hunger > 0) {
        happiness++;
        hunger--;
        energy--;
        updateStats();
    }
});

document.getElementById("rest-btn").addEventListener("click", () => {
    if (energy < 10) {
        energy++;
        updateStats();
    }
});

setInterval(() => {
    if (hunger > 0) hunger--;
    if (happiness > 0) happiness--;
    if (energy > 0) energy--;
    updateStats();
}, 5000);
